#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/wait.h> 


int main (int argc, char *argv [ ] ) { 
    char* option = (argv[1]);
    
    if (argc != 2) { // assertring 1 program argument
        fprintf (stderr, "Usage: %s (w|s)\n", argv[0]); 
        exit(EXIT_FAILURE);  
    
    } else if(*option != 'w' && *option != 's'){ // check for correct option
        fprintf(stderr, "Invalid option. Use 'w' or 's'\n"); 
        exit(EXIT_FAILURE); 
    
    
    } else{
    
        pid_t childPid = fork(); // create child process

        if (childPid == -1){ 
            perror("fork");
            exit(EXIT_FAILURE);
        

        } else if (childPid == 0) { // Child process 
        
            // Execute "./myclock out1" 
            execlp ("./myclock" , "myclock", "out1", ( char *) NULL) ; 
            
            // execlp failed if reached here 
            perror ("execlp") ; exit (EXIT_FAILURE) ;                   
        
        } else { // Parent process 

            int status; 
            
            if (*option == 'w' ) { // Wait for the child process to terminate 
                
                waitpid (childPid, &status, 0);

                if (WIFEXITED (status)) {
                    printf("Child process terminated with exit code: %d\n", WEXITSTATUS (status)) ;

                } else if (WIFSIGNALED (status) ) { 
                    fprintf (stderr, "Child process terminated by signal: %d\n" , WTERMSIG (status));
                    
                }    
                
            } else if (*option == 's' ) { 
                // Sleep for 2 minutes 
                sleep (120);

            }

            exit(EXIT_SUCCESS);   

        }

    }

    return 0;

}
