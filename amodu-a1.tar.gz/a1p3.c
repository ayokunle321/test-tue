#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/times.h>
#include <errno.h>

#define MAXLINE 256
#define MAXARGS 6
#define NPROC 5

struct cmd_info {
    pid_t pid;
    char cmdline[MAXLINE];
} cmds[NPROC];

void print_cmd(const char *cmd) {
    printf("print_cmd(): [%s]\n", cmd);
}

void record_cmd(struct cmd_info *cmds, int index, pid_t pid, const char *cmd) {
    cmds[index].pid = pid;
    strncpy(cmds[index].cmdline, cmd, MAXLINE);
}

int main(int argc, char *argv[]) {
    if (argc != 2 || (argv[1][0] != 'n' && argv[1][0] != 'w' && argv[1][0] != 'a')) {
        fprintf(stderr, "Usage: %s (n|w|a)\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char option = argv[1][0];
    struct tms start_tms, end_tms;
    clock_t start_time, end_time;
    start_time = times(&start_tms);

    int process_count = 0;
    char cmd[MAXLINE];
    char *args[MAXARGS + 1];
    int status;
    pid_t pid;

    while (fgets(cmd, MAXLINE, stdin) != NULL && process_count < NPROC) {
        if (cmd[0] == '#' || cmd[0] == '\n') continue; // Skip comments and empty lines
        cmd[strcspn(cmd, "\n")] = 0; // Remove newline character

        print_cmd(cmd);

        char *token = strtok(cmd, " ");
        int i = 0;
        while (token != NULL && i < MAXARGS) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL; // Null-terminate the argument list

        pid = fork();
        if (pid == 0) { // Child process
            if (execvp(args[0], args) == -1) {
                fprintf(stderr, "child (%d): unable to execute '%s'\n", getpid(), args[0]);
                exit(EXIT_FAILURE);
            }
        } else if (pid > 0) { // Parent process
            record_cmd(cmds, process_count++, pid, cmd);
            if (option != 'n') {
                if (option == 'w' && waitpid(pid, &status, 0) > 0) {
                    printf("process (%d:'%s') exited (status= %d)\n", pid, cmd, WEXITSTATUS(status));
                }
            }
        } else {
            perror("fork failed");
            exit(EXIT_FAILURE);
        }
    }

if (option == 'a') {
    pid_t wpid;
    while ((wpid = waitpid(-1, &status, 0)) > 0) {
        int i;
        for (i = 0; i < process_count; i++) {
            if (cmds[i].pid == wpid) {
                printf("process (%d:'%s') exited (status= %d)\n", wpid, cmds[i].cmdline, WEXITSTATUS(status));
                break; // Exit the loop once the matching PID is found
            }
        }
    }
}

    // Print stored information about commands
    printf("Process table:\n");
    for (int i = 0; i < process_count; i++) {
        printf("%d [%d: '%s']\n", i, cmds[i].pid, cmds[i].cmdline);
    }

    end_time = times(&end_tms);
    long ticks_per_second = sysconf(_SC_CLK_TCK);
    double total_elapsed_time = (double)(end_time - start_time) / ticks_per_second;
    double main_user_time = (double)(end_tms.tms_utime - start_tms.tms_utime) / ticks_per_second;
    double main_system_time = (double)(end_tms.tms_stime - start_tms.tms_stime) / ticks_per_second;
    double child_user_time = (double)(end_tms.tms_cutime - start_tms.tms_cutime) / ticks_per_second;
    double child_system_time = (double)(end_tms.tms_cstime - start_tms.tms_cstime) / ticks_per_second;

    printf("real: %f seconds\n", total_elapsed_time);
    printf("user: %f seconds\n", main_user_time);
    printf("sys: %f seconds\n", main_system_time);
    printf("child user %f seconds\n", child_user_time);
    printf("child sys: %f seconds\n", child_system_time);

    return 0;
}
